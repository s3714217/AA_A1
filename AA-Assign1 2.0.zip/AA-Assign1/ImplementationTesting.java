import java.io.PrintWriter;

public class ImplementationTesting {

	public static void main(String[] args) {
		
		PrintWriter print = new PrintWriter(System.out);
		final int STR = 1000;

		OrderedArrayRQ AR = new OrderedArrayRQ();
		OrderedLinkedListRQ LL = new OrderedLinkedListRQ();
        BinarySearchTreeRQ BST = new BinarySearchTreeRQ();
		        
		print.flush();
		print.close();
		
		
	
		
		
	}}