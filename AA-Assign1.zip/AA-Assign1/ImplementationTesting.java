import java.io.PrintWriter;
import java.util.concurrent.ThreadLocalRandom;

public class ImplementationTesting {

	public static void main(String[] args) {
		
		PrintWriter print = new PrintWriter(System.out);
		final int STR = 1000;
	
		
		//OrderedArrayRQ test = new OrderedArrayRQ();
		OrderedLinkedListRQ test = new OrderedLinkedListRQ();
		
		for(int x = 0; x < STR; x++)
		{
			int randx = ThreadLocalRandom.current().nextInt(100);
			String temp = "P" + randx;
			int rand = ThreadLocalRandom.current().nextInt(10);
			test.enqueue(temp, rand);
		}
		
		test.printAllProcesses(print);
		
		print.flush();
		print.close();
		
		
	
		
		
	}}